import dwm.common
import dwm.datasets.common
import dwm.datasets.nuscenes_common
from dwm.datasets.track_pv.pv_flow import render_instance_flow_images, transform_point
import einops
import random
import fsspec
import json
import os
import time
import numpy as np
from PIL import Image, ImageDraw
import torch
import torchvision.transforms.functional


class MotionDataset(torch.utils.data.Dataset):
    """The motion data loaded from the nuScenes dataset.

    Args:
        fs (fsspec.AbstractFileSystem): The file system for the dataset table
            and content files.
        dataset_name (str): The nuScenes dataset name such as "v1.0-mini",
            "v1.0-trainval".
        sequence_length (int): The frame count of the temporal sequence.
        fps_stride_tuples (list): The list of tuples in the form of
            (FPS, stride). If the FPS > 0, stride is the begin time in second
            between 2 adjacent video clips, else the stride is the index count
            of the beginning between 2 adjacent video clips.
        split (str or None): The split in one of "train", "val", "mini_train",
            "mini_val", following the official split definition of the nuScenes
            dataset, or None for the whole data.
        sensor_channels (list): The string list of required views in
            "LIDAR_TOP", "CAM_FRONT", "CAM_BACK", "CAM_BACK_LEFT",
            "CAM_FRONT_LEFT", "CAM_FRONT_RIGHT", "CAM_BACK_RIGHT", following
            the nuScenes sensor name.
        keyframe_only (bool): If set to True, only the key frames with complete
            annotation information will be included by the data items.
        enable_synchronization_check (bool): When this feature is enabled, if
            the timestamp error of a certain frame in the read video clip
            exceeds half of the frame interval, this video clip will be
            discarded. True as default.
        enable_scene_description (bool): If set to True, the data item will
            include the text of the scene description by "scene_description".
        enable_camera_transforms (bool): If set to True, the data item will
            include the "camera_transforms", "camera_intrinsics", "image_size"
            if camera modality exists, and include "lidar_transforms" if LiDAR
            modality exists. For a detailed definition of transforms, please
            refer to the dataset README.
        enable_ego_transforms (bool): If set to True, the data item will
            include the "ego_transforms". For a detailed definition of
            transforms, please refer to the dataset README.
        enable_sample_data (bool): If set to True, the data item will include
            the "sample_data" for nuScenes sample data objects.
        _3dbox_image_settings (dict or None): If set, the data item will
            include the "3dbox_images".
        hdmap_image_settings (dict or None): If set, the data item will include
            the "hdmap_images".
        image_segmentation_settings (dict or None): If set, the data item will
            include the "segmentation_images".
        foreground_region_image_settings (dict or None): If set, the data item
            will include the "foreground_region_images".
        _3dbox_bev_settings (dict or None): If set, the data item will include
            the "3dbox_bev_images".
        hdmap_bev_settings (dict or None): If set, the data item will include
            the "hdmap_bev_images".
        image_description_settings (dict or None): If set, the data item will
            include the "image_description". The "path" in the setting is for
            the content JSON file. The "time_list_dict_path" in the setting is
            for the file to seek the nearest labelled time points. Please refer
            to dwm.datasets.common.make_image_description_string() for details.
        stub_key_data_dict (dict or None): The dict of stub key and data, to
            align with other datasets with keys and data missing in this
            dataset. Please refer to dwm.datasets.common.add_stub_key_data()
            for details.
    """

    table_names = [
        "calibrated_sensor", "category", "ego_pose", "instance", "log", "map",
        "sample", "sample_annotation", "sample_data", "scene", "sensor"
    ]
    prune_table_plan = [
        ("sample", "scene_token", "scene"),
        ("sample_data", "sample_token", "sample"),
        ("sample_annotation", "sample_token", "sample")
    ]
    index_names = [
        "calibrated_sensor.token", "category.token", "ego_pose.token",
        "instance.token", "log.token", "map.token", "sample.token",
        "sample_data.sample_token", "sample_data.token",
        "sample_annotation.sample_token", "sample_annotation.token",
        "scene.token", "sensor.token"
    ]
    serialized_table_names = [
        "sample", "sample_annotation", "sample_data", "scene"
    ]

    default_3dbox_color_table = {
        "human.pedestrian": (255, 0, 0),
        "vehicle.bicycle": (128, 255, 0),
        "vehicle.motorcycle": (0, 255, 128),
        "vehicle.bus": (128, 0, 255),
        "vehicle.car": (0, 0, 255),
        "vehicle.construction": (128, 128, 255),
        "vehicle.emergency": (255, 128, 128),
        "vehicle.trailer": (255, 255, 255),
        "vehicle.truck": (255, 255, 0)
    }
    default_hdmap_color_table = {
        "drivable_area": (0, 0, 255),
        "lane": (0, 255, 0),
        "ped_crossing": (255, 0, 0)
    }
    default_3dbox_corner_template = [
        [-0.5, -0.5, -0.5, 1], [-0.5, -0.5, 0.5, 1],
        [-0.5, 0.5, -0.5, 1], [-0.5, 0.5, 0.5, 1],
        [0.5, -0.5, -0.5, 1], [0.5, -0.5, 0.5, 1],
        [0.5, 0.5, -0.5, 1], [0.5, 0.5, 0.5, 1]
    ]
    default_3dbox_edge_indices = [
        (0, 1), (0, 2), (1, 3), (2, 3), (0, 4), (1, 5),
        (2, 6), (3, 7), (4, 5), (4, 6), (5, 7), (6, 7),
        (6, 3), (6, 5)
    ]
    default_bev_from_ego_transform = [
        [6.4, 0, 0, 320],
        [0, -6.4, 0, 320],
        [0, 0, -6.4, 0],
        [0, 0, 0, 1]
    ]
    default_bev_3dbox_corner_template = [
        [-0.5, -0.5, 0, 1], [-0.5, 0.5, 0, 1],
        [0.5, -0.5, 0, 1], [0.5, 0.5, 0, 1]
    ]
    default_bev_3dbox_edge_indices = [(0, 2), (2, 3), (3, 1), (1, 0)]

    @staticmethod
    def prune_table(table: list, foreign_key: str, referenced_table: list):
        if referenced_table is None:
            return table
        else:
            referenced_tokens = set(i["token"] for i in referenced_table)
            return [i for i in table if i[foreign_key] in referenced_tokens]

    @staticmethod
    def get_dict_indices(tables: dict, index_name: str):
        table_name, column_name = index_name.split(".")
        return dwm.common.ReadonlyDictIndices(
            [i[column_name] for i in tables[table_name]])

    @staticmethod
    def load_tables(
        fs: fsspec.AbstractFileSystem, dataset_name: str, table_names: list,
        prune_table_plan: list, index_names: list, split=None
    ):
        tables = {
            i: json.loads(
                fs.cat_file("{}/{}.json".format(dataset_name, i)).decode())
            for i in table_names
        }
        if split is not None:
            scene_subset = getattr(dwm.datasets.nuscenes_common, split)
            tables["scene"] = [
                i for i in tables["scene"] if i["name"] in scene_subset
            ]

            for i in prune_table_plan:
                table_name, foreign_key, ref_table_name = i
                tables[table_name] = MotionDataset.prune_table(
                    tables[table_name], foreign_key, tables[ref_table_name])

        indices = {
            i: MotionDataset.get_dict_indices(tables, i)
            for i in index_names
        }
        return tables, indices

    @staticmethod
    def query(
        tables: dict, indices: dict, table_name: str, key: str,
        column_name: str = "token"
    ):
        i = indices["{}.{}".format(table_name, column_name)][key]
        return tables[table_name][i]

    @staticmethod
    def query_range(
        tables: dict, indices: dict, table_name: str, key: str,
        column_name: str = "token"
    ):
        all_indices = indices["{}.{}".format(table_name, column_name)]\
            .get_all_indices(key)
        table = tables[table_name]
        return [table[i] for i in all_indices]

    @staticmethod
    def get_scene_samples(tables: dict, indices: dict, scene: dict):
        result = []
        i = scene["first_sample_token"]
        while i != "":
            sample = MotionDataset.query(tables, indices, "sample", i)
            result.append(sample)
            i = sample["next"]

        return result

    @staticmethod
    def get_sensor(tables: dict, indices: dict, sample_data: dict):
        calibrated_sensor = MotionDataset.query(
            tables, indices, "calibrated_sensor",
            sample_data["calibrated_sensor_token"])
        return MotionDataset.query(
            tables, indices, "sensor", calibrated_sensor["sensor_token"])

    @staticmethod
    def check_sensor(
        tables: dict, indices: dict, sample_data: dict, channel=None,
        modality=None
    ):
        sensor = MotionDataset.get_sensor(tables, indices, sample_data)
        is_channel = channel is None or sensor["channel"] == channel
        is_modality = modality is None or sensor["modality"] == modality
        return is_channel and is_modality

    @staticmethod
    def enumerate_segments(
        channel_sample_data_list: list, sequence_length: int, fps, stride,
        enable_synchronization_check: bool
    ):
        # stride == 0: all segments are begin with key frames.
        # stride > 0:
        #   * FPS == 0: offset between segment beginings are by index.
        #   * FPS > 0: offset between segment beginings are by second.

        csdl = channel_sample_data_list
        channel_timestamp_list = [
            [i["timestamp"] for i in sdl] for sdl in csdl
        ]
        channel_key_frame_timestamp_list = [
            [i["timestamp"] for i in sdl if i["is_key_frame"]]
            for sdl in csdl
        ]
        if fps == 0:
            # frames are extracted by the index.
            channel_key_frame_index_list = [
                [i_id for i_id, i in enumerate(sdl) if i["is_key_frame"]]
                for sdl in csdl
            ]
            for t in range(0, len(csdl[0]), max(1, stride)):
                # find the indices of the first frame of channels matching the
                # given timestamp
                ct0 = [
                    dwm.datasets.common.find_nearest(
                        tl, csdl[0][t]["timestamp"])
                    for tl in channel_timestamp_list
                ] if stride != 0 else [
                    kfil[
                        dwm.datasets.common.find_nearest(
                            kftl, csdl[0][t]["timestamp"])]
                    for kfil, kftl in zip(
                        channel_key_frame_index_list,
                        channel_key_frame_timestamp_list)
                ]

                if (stride != 0 or csdl[0][t]["is_key_frame"]) and all([
                    t0 + sequence_length <= len(sdl)
                    for t0, sdl in zip(ct0, csdl)
                ]):
                    yield [
                        [sdl[t0 + i]["token"] for t0, sdl in zip(ct0, csdl)]
                        for i in range(sequence_length)
                    ]

        else:
            # frames are extracted by the timestamp.
            def enumerate_begin_time(sdl, sequence_duration, stride):
                s = sdl[-1]["timestamp"] / 1000000 - sequence_duration
                if stride == 0:
                    for i in sdl:
                        t = i["timestamp"] / 1000000
                        if i["is_key_frame"] and t <= s:
                            yield t

                else:
                    t = sdl[0]["timestamp"] / 1000000
                    while t <= s:
                        yield t
                        t += stride

            channel_key_frame_list = [
                [i for i in sdl if i["is_key_frame"]]
                for sdl in csdl
            ]
            for t in enumerate_begin_time(
                csdl[0], sequence_length / fps, stride
            ):
                # find the indices of the first frame of channels matching the
                # given timestamp
                ct0 = [t * 1000000 for _ in csdl] if stride != 0 else [
                    kfl[dwm.datasets.common.find_nearest(kftl, t)]["timestamp"]
                    for kfl, kftl in zip(
                        channel_key_frame_list,
                        channel_key_frame_timestamp_list)
                ]

                channel_expected_times = [
                    [t0 + i / fps * 1000000 for i in range(sequence_length)]
                    for t0 in ct0
                ]
                channel_candidates = [
                    [
                        sdl[dwm.datasets.common.find_nearest(timestamps, i)]
                        for i in expected_times
                    ]
                    for sdl, timestamps, expected_times in zip(
                        csdl, channel_timestamp_list, channel_expected_times)
                ]
                max_time_error = max([
                    abs(i0["timestamp"] - i1)
                    for candidates, expected_times in zip(
                        channel_candidates, channel_expected_times)
                    for i0, i1 in zip(candidates, expected_times)
                ])
                if (
                    not enable_synchronization_check or
                    max_time_error <= 500000 / fps
                ):
                    yield [
                        [
                            candidates[i]["token"]
                            for candidates in channel_candidates
                        ]
                        for i in range(sequence_length)
                    ]

    @staticmethod
    def get_transform(
        tables: dict, indices: dict, table_name: str, queried_key: str,
        output_type: str = "np"
    ):
        posed_object = MotionDataset.query(
            tables, indices, table_name, queried_key)
        return dwm.datasets.common.get_transform(
            posed_object["rotation"], posed_object["translation"], output_type)

    @staticmethod
    def draw_lines_to_image(
        nodes: list, draw: ImageDraw, transform: np.array,
        max_distance: float, pen_color: tuple, pen_width: int
    ):
        if len(nodes) == 0:
            return

        polygon_nodes = np.array(nodes).transpose().reshape(4, -1)
        p = (transform @ polygon_nodes).reshape(4, 2, -1)
        m = p.shape[-1]
        for i in range(m):
            xy = dwm.datasets.common.project_line(
                p[:, 0, i], p[:, 1, i], far_z=max_distance)
            if xy is not None:
                draw.line(xy, fill=pen_color, width=pen_width)

    @staticmethod
    def draw_polygon_to_bev_image(
        polygon: dict, nodes: list, draw: ImageDraw, transform: np.array,
        pen_color: tuple, pen_width: int, solid: bool = False
    ):
        polygon_nodes = np.array([
            [nodes[i]["x"], nodes[i]["y"], 0, 1]
            for i in polygon["exterior_node_tokens"]
        ]).transpose()
        p = transform @ polygon_nodes
        draw.polygon(
            [(p[0, i], p[1, i]) for i in range(p.shape[1])],
            fill=pen_color if solid else None,
            outline=None if solid else pen_color, width=pen_width)

        for i in polygon["holes"]:
            hole_nodes = np.array([
                [nodes[j]["x"], nodes[j]["y"], 0, 1] for j in i["node_tokens"]
            ]).transpose()
            p = transform @ hole_nodes
            draw.polygon(
                [(p[0, i], p[1, i]) for i in range(p.shape[1])],
                fill=(0, 0, 0) if solid else None,
                outline=None if solid else pen_color, width=pen_width)

    @staticmethod
    def get_images(
        fs: fsspec.AbstractFileSystem, tables: dict, indices: dict,
        sample_data_list: list
    ):
        images = []
        for i in sample_data_list:
            if MotionDataset.check_sensor(
                    tables, indices, i, modality="camera"):
                with fs.open(i["filename"]) as f:
                    image = Image.open(f)
                    image.load()
                images.append(image)
        return images

    @staticmethod
    def get_3dbox_image(
        tables: dict, indices: dict, sample_data: dict, _3dbox_image_settings: dict
    ):
        # options
        pen_width = _3dbox_image_settings.get("pen_width", 8)
        color_table = _3dbox_image_settings.get(
            "color_table", MotionDataset.default_3dbox_color_table)
        corner_templates = _3dbox_image_settings.get(
            "corner_templates", MotionDataset.default_3dbox_corner_template)
        edge_indices = _3dbox_image_settings.get(
            "edge_indices", MotionDataset.default_3dbox_edge_indices)

        # get the transform from the referenced ego space to the image space
        calibrated_sensor = MotionDataset.query(
            tables, indices, "calibrated_sensor",
            sample_data["calibrated_sensor_token"])
        intrinsic = np.eye(4)
        intrinsic[:3, :3] = np.array(calibrated_sensor["camera_intrinsic"])

        ego_from_camera = dwm.datasets.common.get_transform(
            calibrated_sensor["rotation"], calibrated_sensor["translation"])
        world_from_ego = dwm.datasets.common.get_transform(
            sample_data["rotation"], sample_data["translation"])
        camera_from_world = np.linalg.inv(world_from_ego @ ego_from_camera)
        image_from_world = intrinsic @ camera_from_world

        # draw annotations to the image
        image = Image.new("RGB", (sample_data["width"], sample_data["height"]))
        if not sample_data["is_key_frame"]:
            return image

        draw = ImageDraw.Draw(image)

        corner_templates_np = np.array(corner_templates).transpose()
        for sa in MotionDataset.query_range(
                tables, indices, "sample_annotation",
                sample_data["sample_token"], column_name="sample_token"):
            instance = MotionDataset.query(
                tables, indices, "instance", sa["instance_token"])
            category = MotionDataset.query(
                tables, indices, "category", instance["category_token"])

            # check the category from the color table
            color = None
            for i, c in color_table.items():
                if category["name"].startswith(i):
                    color = c if isinstance(c, tuple) else tuple(c)
                    break

            if color is None:
                continue

            # get the transform from the annotation template to the world space
            scale = np.diag([sa["size"][1], sa["size"][0], sa["size"][2], 1])
            world_from_annotation = dwm.datasets.common.get_transform(
                sa["rotation"], sa["translation"])

            # project and render lines
            image_corners = image_from_world @ world_from_annotation @ \
                scale @ corner_templates_np
            for a, b in edge_indices:
                xy = dwm.datasets.common.project_line(
                    image_corners[:, a], image_corners[:, b])
                if xy is not None:
                    draw.line(xy, fill=color, width=pen_width)

        return image

    @staticmethod
    def draw_polygen_to_image(
        polygon: dict, nodes: list, draw: ImageDraw, transform: np.array,
        max_distance: float, pen_color: tuple, pen_width: int
    ):
        polygon_nodes = np.array([
            [nodes[i]["x"], nodes[i]["y"], 0, 1]
            for i in polygon["exterior_node_tokens"]
        ]).transpose()
        p = transform @ polygon_nodes
        m = len(polygon["exterior_node_tokens"])
        for i in range(m):
            xy = dwm.datasets.common.project_line(
                p[:, i], p[:, (i + 1) % m], far_z=max_distance)
            if xy is not None:
                draw.line(xy, fill=pen_color, width=pen_width)

        for i in polygon["holes"]:
            hole_nodes = np.array([
                [nodes[j]["x"], nodes[j]["y"], 0, 1] for j in i["node_tokens"]
            ]).transpose()
            p = transform @ hole_nodes
            m = len(i["node_tokens"])
            for j in range(m):
                xy = dwm.datasets.common.project_line(
                    p[:, j], p[:, (j + 1) % m], far_z=max_distance)
                if xy is not None:
                    draw.line(xy, fill=pen_color, width=pen_width)

    @staticmethod
    def get_hdmap_image(
        map_expansion: dict, map_expansion_dict: dict, tables: dict,
        indices: dict, sample_data: dict, hdmap_image_settings: dict
    ):
        # options
        max_distance = hdmap_image_settings.get("max_distance", 65.0)
        pen_width = hdmap_image_settings.get("pen_width", 8)
        color_table = hdmap_image_settings.get(
            "color_table", MotionDataset.default_hdmap_color_table)

        # get the transform from the world (map) space to the image space
        calibrated_sensor = MotionDataset.query(
            tables, indices, "calibrated_sensor",
            sample_data["calibrated_sensor_token"])
        intrinsic = np.eye(4)
        intrinsic[:3, :3] = np.array(calibrated_sensor["camera_intrinsic"])
        ego_from_camera = dwm.datasets.common.get_transform(
            calibrated_sensor["rotation"], calibrated_sensor["translation"])
        world_from_ego = dwm.datasets.common.get_transform(
            sample_data["rotation"], sample_data["translation"])
        camera_from_world = np.linalg.inv(world_from_ego @ ego_from_camera)
        image_from_world = intrinsic @ camera_from_world

        # draw map elements to the image
        image = Image.new("RGB", (sample_data["width"], sample_data["height"]))
        draw = ImageDraw.Draw(image)

        sample = MotionDataset.query(
            tables, indices, "sample", sample_data["sample_token"])
        scene = MotionDataset.query(
            tables, indices, "scene", sample["scene_token"])
        log = MotionDataset.query(tables, indices, "log", scene["log_token"])
        map = map_expansion[log["location"]]
        map_dict = map_expansion_dict[log["location"]]
        nodes = map_dict["node"]
        polygons = map_dict["polygon"]

        if "lane" in color_table and "lane" in map:
            pen_color = tuple(color_table["lane"])
            for i in map["lane"]:
                MotionDataset.draw_polygen_to_image(
                    polygons[i["polygon_token"]], nodes, draw,
                    image_from_world, max_distance, pen_color, pen_width)

        if "drivable_area" in color_table and "drivable_area" in map:
            pen_color = tuple(color_table["drivable_area"])
            for i in map["drivable_area"]:
                for polygon_token in i["polygon_tokens"]:
                    MotionDataset.draw_polygen_to_image(
                        polygons[polygon_token], nodes, draw, image_from_world,
                        max_distance, pen_color, pen_width)

        if "ped_crossing" in color_table and "ped_crossing" in map:
            pen_color = tuple(color_table["ped_crossing"])
            for i in map["ped_crossing"]:
                MotionDataset.draw_polygen_to_image(
                    polygons[i["polygon_token"]], nodes, draw,
                    image_from_world, max_distance, pen_color, pen_width)

        return image

    @staticmethod
    def get_foreground_region_image(
        tables: dict, indices: dict, sample_data: dict,
        foreground_region_image_settings: dict
    ):
        # options
        foreground_color = tuple(
            foreground_region_image_settings.get(
                "foreground_color", [255, 255, 255]))
        background_color = tuple(
            foreground_region_image_settings.get(
                "background_color", [0, 0, 0]))
        foreground_categories = foreground_region_image_settings.get(
            "categories", MotionDataset.default_3dbox_color_table.keys())
        corner_templates = foreground_region_image_settings.get(
            "corner_templates", MotionDataset.default_3dbox_corner_template)

        # get the transform from the referenced ego space to the image space
        calibrated_sensor = MotionDataset.query(
            tables, indices, "calibrated_sensor",
            sample_data["calibrated_sensor_token"])
        intrinsic = np.eye(4)
        intrinsic[:3, :3] = np.array(calibrated_sensor["camera_intrinsic"])

        ego_from_camera = dwm.datasets.common.get_transform(
            calibrated_sensor["rotation"], calibrated_sensor["translation"])
        world_from_ego = dwm.datasets.common.get_transform(
            sample_data["rotation"], sample_data["translation"])
        camera_from_world = np.linalg.inv(world_from_ego @ ego_from_camera)
        image_from_world = intrinsic @ camera_from_world

        # draw annotations to the image
        image = Image.new(
            "RGB", (sample_data["width"], sample_data["height"]),
            background_color)
        if not sample_data["is_key_frame"]:
            return image

        draw = ImageDraw.Draw(image)

        corner_templates_np = np.array(corner_templates).transpose()
        for sa in MotionDataset.query_range(
                tables, indices, "sample_annotation",
                sample_data["sample_token"], column_name="sample_token"):
            instance = MotionDataset.query(
                tables, indices, "instance", sa["instance_token"])
            category = MotionDataset.query(
                tables, indices, "category", instance["category_token"])

            # check the category from the color table
            out_of_categories = True
            for i in foreground_categories:
                if category["name"].startswith(i):
                    out_of_categories = False
                    break

            if out_of_categories:
                continue

            # get the transform from the annotation template to the world space
            scale = np.diag([sa["size"][1], sa["size"][0], sa["size"][2], 1])
            world_from_annotation = dwm.datasets.common.get_transform(
                sa["rotation"], sa["translation"])

            # project and render lines
            image_corners = image_from_world @ world_from_annotation @ \
                scale @ corner_templates_np

            # All points are in the front of the camera
            if np.min(image_corners[2], -1) > 0:
                p = image_corners[:2] / image_corners[2]
                top_left = np.min(p, -1)
                bottom_right = np.max(p, -1)
                draw.rectangle(
                    tuple(np.concatenate([top_left, bottom_right]).tolist()),
                    fill=foreground_color)

        return image

    @staticmethod
    def get_3dbox_bev_image(
        tables: dict, indices: dict, sample_data: dict,
        _3dbox_bev_settings: dict
    ):
        # options
        pen_width = _3dbox_bev_settings.get("pen_width", 2)
        bev_size = _3dbox_bev_settings.get("bev_size", [640, 640])
        bev_from_ego_transform = _3dbox_bev_settings.get(
            "bev_from_ego_transform",
            MotionDataset.default_bev_from_ego_transform)
        fill_box = _3dbox_bev_settings.get("fill_box", False)
        color_table = _3dbox_bev_settings.get(
            "color_table", MotionDataset.default_3dbox_color_table)
        corner_templates = _3dbox_bev_settings.get(
            "corner_templates",
            MotionDataset.default_bev_3dbox_corner_template)
        edge_indices = _3dbox_bev_settings.get(
            "edge_indices", MotionDataset.default_bev_3dbox_edge_indices)

        # get the transform from the world space to the BEV space
        world_from_ego = dwm.datasets.common.get_transform(
            sample_data["rotation"], sample_data["translation"])
        ego_from_world = np.linalg.inv(world_from_ego)
        bev_from_ego = np.array(bev_from_ego_transform, np.float32)
        bev_from_world = bev_from_ego @ ego_from_world

        # draw annotations to the image
        image = Image.new("RGB", tuple(bev_size))
        if not sample_data["is_key_frame"]:
            return image

        draw = ImageDraw.Draw(image)

        corner_templates_np = np.array(corner_templates).transpose()
        for sa in MotionDataset.query_range(
                tables, indices, "sample_annotation",
                sample_data["sample_token"], column_name="sample_token"):
            instance = MotionDataset.query(
                tables, indices, "instance", sa["instance_token"])
            category = MotionDataset.query(
                tables, indices, "category", instance["category_token"])

            # check the category from the color table
            color = None
            for i, c in color_table.items():
                if category["name"].startswith(i):
                    color = c if isinstance(c, tuple) else tuple(c)
                    break

            if color is None:
                continue

            # get the transform from the annotation template to the world space
            scale = np.diag([sa["size"][1], sa["size"][0], sa["size"][2], 1])
            world_from_annotation = dwm.datasets.common.get_transform(
                sa["rotation"], sa["translation"])

            # project and render lines
            image_corners = bev_from_world @ world_from_annotation @ scale @ \
                corner_templates_np
            p = image_corners[:2]
            if fill_box:
                draw.polygon(
                    [(p[0, a], p[1, a]) for a, _ in edge_indices],
                    fill=color, width=pen_width)
            else:
                for a, b in edge_indices:
                    draw.line(
                        (p[0, a], p[1, a], p[0, b], p[1, b]),
                        fill=color, width=pen_width)

        return image


    @staticmethod
    def _mdtoken_dynamic_class_id(category_name):
        name = str(category_name).lower()

        if "truck" in name:
            return 1
        if "bus" in name:
            return 3
        if "trailer" in name:
            return 4
        if "barrier" in name:
            return 5
        if "motorcycle" in name:
            return 6
        if "bicycle" in name or "cyclist" in name or "bike" in name:
            return 7
        if "pedestrian" in name or "ped" in name:
            return 8
        if "cone" in name:
            return 9
        if "vehicle" in name or "car" in name:
            return 0
        if "regular_vehicle" in name or "large_vehicle" in name:
            return 0

        return 0

    @staticmethod
    def _mdtoken_yaw_from_quaternion(q):
        q = np.asarray(q, dtype=np.float32).reshape(-1)

        if q.shape[0] != 4:
            return 0.0

        qw, qx, qy, qz = [float(v) for v in q]

        siny_cosp = 2.0 * (qw * qz + qx * qy)
        cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)

        return float(np.arctan2(siny_cosp, cosy_cosp))

    @staticmethod
    def _mdtoken_box7_from_dict(obj):
        if not isinstance(obj, dict):
            return None, None

        name = (
            obj.get("category_name", None)
            or obj.get("category", None)
            or obj.get("label", None)
            or obj.get("name", None)
            or obj.get("type", None)
            or "car"
        )

        if all(k in obj for k in ["tx_m", "ty_m", "tz_m", "length_m", "width_m", "height_m"]):
            x = float(obj["tx_m"])
            y = float(obj["ty_m"])
            z = float(obj["tz_m"])
            length = float(obj["length_m"])
            width = float(obj["width_m"])
            height = float(obj["height_m"])

            if all(k in obj for k in ["qw", "qx", "qy", "qz"]):
                yaw = MotionDataset._mdtoken_yaw_from_quaternion(
                    [obj["qw"], obj["qx"], obj["qy"], obj["qz"]]
                )
            else:
                yaw = float(obj.get("yaw", obj.get("heading", 0.0)))

            return np.asarray(
                [x, y, z, length, width, height, yaw],
                dtype=np.float32,
            ), name

        if "translation" in obj and ("size" in obj or "dimensions" in obj):
            t = np.asarray(obj["translation"], dtype=np.float32).reshape(-1)
            s = np.asarray(
                obj.get("size", obj.get("dimensions")),
                dtype=np.float32,
            ).reshape(-1)

            if t.shape[0] < 3 or s.shape[0] < 3:
                return None, name

            if "rotation" in obj:
                yaw = MotionDataset._mdtoken_yaw_from_quaternion(obj["rotation"])
            else:
                yaw = float(obj.get("yaw", obj.get("heading", 0.0)))

            return np.asarray(
                [t[0], t[1], t[2], s[0], s[1], s[2], yaw],
                dtype=np.float32,
            ), name

        if "center" in obj and ("size" in obj or "dimensions" in obj):
            c = np.asarray(obj["center"], dtype=np.float32).reshape(-1)
            s = np.asarray(
                obj.get("size", obj.get("dimensions")),
                dtype=np.float32,
            ).reshape(-1)

            if c.shape[0] < 3 or s.shape[0] < 3:
                return None, name

            yaw = float(obj.get("yaw", obj.get("heading", 0.0)))

            return np.asarray(
                [c[0], c[1], c[2], s[0], s[1], s[2], yaw],
                dtype=np.float32,
            ), name

        return None, name

    @staticmethod
    def _mdtoken_box_corners_lidar_xyz(box7):
        box7 = np.asarray(box7[:7], dtype=np.float32)

        if not np.isfinite(box7).all():
            return None

        x, y, z, length, width, height, yaw = [float(v) for v in box7]

        local = np.array(
            [
                [-0.5 * length, -0.5 * width, -0.5 * height],
                [-0.5 * length, -0.5 * width,  0.5 * height],
                [-0.5 * length,  0.5 * width, -0.5 * height],
                [-0.5 * length,  0.5 * width,  0.5 * height],
                [ 0.5 * length, -0.5 * width, -0.5 * height],
                [ 0.5 * length, -0.5 * width,  0.5 * height],
                [ 0.5 * length,  0.5 * width, -0.5 * height],
                [ 0.5 * length,  0.5 * width,  0.5 * height],
            ],
            dtype=np.float32,
        )

        c = np.cos(yaw)
        s = np.sin(yaw)

        rot = np.array(
            [
                [c, -s, 0.0],
                [s,  c, 0.0],
                [0.0, 0.0, 1.0],
            ],
            dtype=np.float32,
        )

        center = np.asarray([x, y, z], dtype=np.float32)
        return local @ rot.T + center[None, :]

    @staticmethod
    def _mdtoken_order_bev_polygon(pts):
        pts = np.asarray(pts, dtype=np.float32)
        center = pts.mean(axis=0)

        angles = np.arctan2(
            pts[:, 1] - center[1],
            pts[:, 0] - center[0],
        )

        order = np.argsort(angles)

        return [
            (float(pts[i, 0]), float(pts[i, 1]))
            for i in order
        ]

    @staticmethod
    def _mdtoken_extract_dynamic_objects(sample_data, hdmap_bev_settings):
        if sample_data is None or not isinstance(sample_data, dict):
            return []

        box_key = hdmap_bev_settings.get("dynamic_boxes_key", None)
        name_key = hdmap_bev_settings.get("dynamic_names_key", None)

        box_candidates = []
        name_candidates = []

        if box_key is not None and box_key in sample_data:
            box_candidates.append(sample_data[box_key])

        for k in ["gt_boxes", "boxes", "bbox", "bboxes", "cuboids"]:
            if k in sample_data:
                box_candidates.append(sample_data[k])

        if name_key is not None and name_key in sample_data:
            name_candidates.append(sample_data[name_key])

        for k in ["gt_names", "names", "labels", "categories", "classes"]:
            if k in sample_data:
                name_candidates.append(sample_data[k])

        if len(box_candidates) > 0:
            boxes = box_candidates[0]
            names = name_candidates[0] if len(name_candidates) > 0 else []

            if isinstance(names, np.ndarray):
                names = names.tolist()

            objects = []
            for i, box in enumerate(boxes):
                name = names[i] if isinstance(names, (list, tuple)) and i < len(names) else "car"

                if isinstance(box, dict):
                    box7, dict_name = MotionDataset._mdtoken_box7_from_dict(box)
                    if dict_name is not None:
                        name = dict_name
                else:
                    box_arr = np.asarray(box, dtype=np.float32).reshape(-1)
                    if box_arr.shape[0] < 7:
                        continue
                    box7 = box_arr[:7]

                if box7 is None:
                    continue

                objects.append((box7, name))

            return objects

        for k in ["annotations", "annos", "objects", "tracks", "track_labels"]:
            if k not in sample_data:
                continue

            records = sample_data[k]
            objects = []

            if isinstance(records, dict):
                records = list(records.values())

            for obj in records:
                box7, name = MotionDataset._mdtoken_box7_from_dict(obj)
                if box7 is not None:
                    objects.append((box7, name))

            if len(objects) > 0:
                return objects

        return []

    @staticmethod
    def _get_dynamic_object_bev_masks_from_sample_data(
        sample_data,
        hdmap_bev_settings,
        bev_h,
        bev_w,
        bev_from_ego,
        num_obj_classes=10,
    ):
        obj_masks = np.zeros(
            (bev_h, bev_w, num_obj_classes),
            dtype=np.uint8,
        )

        objects = MotionDataset._mdtoken_extract_dynamic_objects(
            sample_data,
            hdmap_bev_settings,
        )

        if len(objects) == 0:
            return obj_masks

        for box7, name in objects:
            corners = MotionDataset._mdtoken_box_corners_lidar_xyz(box7)
            if corners is None:
                continue

            cls_id = int(MotionDataset._mdtoken_dynamic_class_id(name))

            if cls_id < 0 or cls_id >= num_obj_classes:
                continue

            bottom_idx = np.argsort(corners[:, 2])[:4]
            bottom = corners[bottom_idx].astype(np.float32)

            pts_h = np.concatenate(
                [
                    bottom,
                    np.ones((bottom.shape[0], 1), dtype=np.float32),
                ],
                axis=1,
            )

            uv = (bev_from_ego @ pts_h.T).T[:, :2].astype(np.float32)

            if uv[:, 0].max() < 0:
                continue
            if uv[:, 0].min() >= bev_w:
                continue
            if uv[:, 1].max() < 0:
                continue
            if uv[:, 1].min() >= bev_h:
                continue

            poly = MotionDataset._mdtoken_order_bev_polygon(uv)

            channel_img = Image.fromarray(obj_masks[:, :, cls_id], mode="L")
            draw = ImageDraw.Draw(channel_img)
            draw.polygon(poly, fill=255)
            obj_masks[:, :, cls_id] = np.asarray(channel_img, dtype=np.uint8)

        return obj_masks


    @staticmethod
    def get_hdmap_bev_image(
        map_expansion: dict, map_expansion_dict: dict, tables: dict,
        indices: dict, sample_data: dict, hdmap_bev_settings: dict
    ):
        # options
        pen_width = hdmap_bev_settings.get("pen_width", 2)
        bev_size = hdmap_bev_settings.get("bev_size", [640, 640])
        bev_from_ego_transform = hdmap_bev_settings.get(
            "bev_from_ego_transform",
            MotionDataset.default_bev_from_ego_transform)
        color_table = hdmap_bev_settings.get(
            "color_table", MotionDataset.default_hdmap_color_table)
        fill_map = hdmap_bev_settings.get("fill_map", True)
        # get the transform from the world (map) space to the BEV space
        world_from_ego = dwm.datasets.common.get_transform(
            sample_data["rotation"], sample_data["translation"])
        bev_from_ego = np.array(bev_from_ego_transform, np.float32)
        bev_from_world = bev_from_ego @ np.linalg.inv(world_from_ego)

        # draw map elements to the image
        image = Image.new("RGB", tuple(bev_size))
        draw = ImageDraw.Draw(image)

        sample = MotionDataset.query(
            tables, indices, "sample", sample_data["sample_token"])
        scene = MotionDataset.query(
            tables, indices, "scene", sample["scene_token"])
        log = MotionDataset.query(tables, indices, "log", scene["log_token"])
        map = map_expansion[log["location"]]
        map_dict = map_expansion_dict[log["location"]]
        nodes = map_dict["node"]
        polygons = map_dict["polygon"]

        if "drivable_area" in color_table and "drivable_area" in map:
            pen_color = tuple(color_table["drivable_area"])
            for i in map["drivable_area"]:
                for polygon_token in i["polygon_tokens"]:
                    MotionDataset.draw_polygon_to_bev_image(
                        polygons[polygon_token], nodes, draw, bev_from_world,
                        (0, 0, 255), pen_width, solid=fill_map)

        if "ped_crossing" in color_table and "ped_crossing" in map:
            pen_color = tuple(color_table["ped_crossing"])
            for i in map["ped_crossing"]:
                MotionDataset.draw_polygon_to_bev_image(
                    polygons[i["polygon_token"]], nodes, draw, bev_from_world,
                    (255, 0, 0), pen_width, solid=fill_map)

        if "lane" in color_table and "lane" in map:
            pen_color = tuple(color_table["lane"])
            for i in map["lane"]:
                MotionDataset.draw_polygon_to_bev_image(
                    polygons[i["polygon_token"]], nodes, draw, bev_from_world,
                    pen_color, pen_width)

        if bool(hdmap_bev_settings.get("append_dynamic_object_mask", False)):
            num_obj_classes = int(hdmap_bev_settings.get("num_object_classes", 10))

            obj_masks = MotionDataset._get_dynamic_object_bev_masks_from_sample_data(
                sample_data,
                hdmap_bev_settings,
                int(bev_size[1]),
                int(bev_size[0]),
                bev_from_ego,
                num_obj_classes=num_obj_classes,
            )

            image_np = np.asarray(image, dtype=np.uint8)
            image_np = np.concatenate(
                [image_np, obj_masks],
                axis=-1,
            )

            return image_np

        return image

    @staticmethod
    def get_segmentation_image(
        fs: fsspec.AbstractFileSystem, sample_data: dict,
        image_segmentation_settings: dict
    ):
        gw = image_segmentation_settings.get("gw", 4)
        gh = image_segmentation_settings.get("gh", 2)
        total_channels = image_segmentation_settings.get("total_channels", 19)
        path = "{}.png".format(sample_data["filename"])
        with fs.open(path) as f:
            image = Image.open(f)
            return einops.rearrange(
                torchvision.transforms.functional.to_tensor(image),
                "c (gh h) (gw w) -> (gh gw c) h w", gh=gh, gw=gw
            )[:total_channels]

    @staticmethod
    def get_image_description(
        tables: dict, indices: dict, image_descriptions: dict,
        time_list_dict: dict, scene: str, sample_data: dict
    ):
        sensor = MotionDataset.get_sensor(tables, indices, sample_data)
        scene_camera = "{}|{}".format(scene, sensor["channel"])
        time_list = time_list_dict[scene_camera]
        nearest_time = dwm.datasets.common.find_nearest(
            time_list, sample_data["timestamp"], return_item=True)
        return image_descriptions["{}|{}".format(scene_camera, nearest_time)]

    def _layout_box_visible_in_nusc_camera(
        self,
        corners_np,
        ref_sample_data,
        camera_sample_data,
    ):
        if camera_sample_data is None:
            raise ValueError("nuScenes box visibility requires camera sample data.")

        if not MotionDataset.check_sensor(
            self.tables,
            self.indices,
            camera_sample_data,
            modality="camera",
        ):
            return False

        corners_np = np.asarray(corners_np, dtype=np.float32)

        if corners_np.shape != (8, 3):
            return False

        if not np.isfinite(corners_np).all():
            return False

        calibrated_sensor = MotionDataset.query(
            self.tables,
            self.indices,
            "calibrated_sensor",
            camera_sample_data["calibrated_sensor_token"],
        )

        image_w = int(camera_sample_data["width"])
        image_h = int(camera_sample_data["height"])

        if image_w <= 0 or image_h <= 0:
            raise ValueError(
                f"Invalid nuScenes camera image size: {image_w}x{image_h}"
            )

        intrinsic = np.eye(4, dtype=np.float32)
        intrinsic[:3, :3] = np.asarray(
            calibrated_sensor["camera_intrinsic"],
            dtype=np.float32,
        )

        ego_from_camera = dwm.datasets.common.get_transform(
            calibrated_sensor["rotation"],
            calibrated_sensor["translation"],
        ).astype(np.float32)

        world_from_ref = dwm.datasets.common.get_transform(
            ref_sample_data["rotation"],
            ref_sample_data["translation"],
        ).astype(np.float32)

        world_from_camera_ego = dwm.datasets.common.get_transform(
            camera_sample_data["rotation"],
            camera_sample_data["translation"],
        ).astype(np.float32)

        camera_from_ref = np.linalg.solve(
            world_from_camera_ego @ ego_from_camera,
            world_from_ref,
        ).astype(np.float32)

        image_from_ref = intrinsic @ camera_from_ref

        corners_h = np.concatenate(
            [
                corners_np,
                np.ones((corners_np.shape[0], 1), dtype=np.float32),
            ],
            axis=1,
        )

        proj = (image_from_ref @ corners_h.T).T
        depth = proj[:, 2]
        valid_depth = depth > 1e-5

        if not np.any(valid_depth):
            return False

        proj = proj[valid_depth]
        depth = depth[valid_depth]

        u = proj[:, 0] / depth
        v = proj[:, 1] / depth

        if u.max() < 0.0:
            return False
        if u.min() >= float(image_w):
            return False
        if v.max() < 0.0:
            return False
        if v.min() >= float(image_h):
            return False

        return True

    def get_layout_token_boxes(self, frame_items):
        max_boxes = self.layout_token_settings.get("max_boxes", 64)

        camera_items = [
            i for i in frame_items
            if MotionDataset.check_sensor(
                self.tables,
                self.indices,
                i,
                modality="camera",
            )
        ]

        if len(camera_items) == 0:
            raise ValueError("nuScenes layout tokens require at least one camera.")
        view_count = len(camera_items)

        corners = torch.zeros(view_count, max_boxes, 8, 3, dtype=torch.float32)
        classes = torch.zeros(view_count, max_boxes, dtype=torch.long)
        masks = torch.zeros(view_count, max_boxes, dtype=torch.float32)

        ref_sample_data = self.get_bev_map_frame_reference(frame_items)

        sample = MotionDataset.query(
            self.tables,
            self.indices,
            "sample",
            ref_sample_data["sample_token"],
        )

        annotations = MotionDataset.query_range(
            self.tables,
            self.indices,
            "sample_annotation",
            sample["token"],
            column_name="sample_token",
        )

        ego_to_global = dwm.datasets.common.get_transform(
            ref_sample_data["rotation"],
            ref_sample_data["translation"],
            "pt",
        )
        global_to_ego = torch.linalg.inv(ego_to_global)

        corner_template = torch.tensor(
            self.default_3dbox_corner_template,
            dtype=torch.float32,
        )

        kept = 0

        for ann in annotations:
            if kept >= max_boxes:
                break

            instance = MotionDataset.query(
                self.tables,
                self.indices,
                "instance",
                ann["instance_token"],
            )
            category = MotionDataset.query(
                self.tables,
                self.indices,
                "category",
                instance["category_token"],
            )

            box_to_global = dwm.datasets.common.get_transform(
                ann["rotation"],
                ann["translation"],
                "pt",
            )
            box_to_ego = global_to_ego @ box_to_global

            size = torch.tensor(
                [ann["size"][1], ann["size"][0], ann["size"][2]],
                dtype=torch.float32,
            )

            local_corners = corner_template.clone()
            local_corners[:, :3] = local_corners[:, :3] * size.view(1, 3)

            ego_corners = (box_to_ego @ local_corners.t()).t()[:, :3]
            ego_corners_np = ego_corners.detach().cpu().numpy()
            class_id = int(self.get_layout_token_class_id(category["name"]))

            for view_idx in range(view_count):
                corners[view_idx, kept] = ego_corners
                classes[view_idx, kept] = class_id

                visible = self._layout_box_visible_in_nusc_camera(
                    ego_corners_np,
                    ref_sample_data,
                    camera_items[view_idx],
                )

                if visible:
                    masks[view_idx, kept] = 1.0

            kept += 1

        return corners, classes, masks
    def get_layout_token_class_id(self, category_name):
        if "vehicle.car" in category_name:
            return 0
        if "vehicle.truck" in category_name:
            return 1
        if "vehicle.construction" in category_name:
            return 2
        if "vehicle.bus" in category_name:
            return 3
        if "vehicle.trailer" in category_name:
            return 4
        if "movable_object.barrier" in category_name:
            return 5
        if "vehicle.motorcycle" in category_name:
            return 6
        if "vehicle.bicycle" in category_name:
            return 7
        if "human.pedestrian" in category_name:
            return 8
        if "movable_object.trafficcone" in category_name:
            return 9

        return 0
    def get_bev_map_frame_reference(self, frame_items):
        reference_channel = None
        if self.layout_token_settings is not None:
            reference_channel = self.layout_token_settings.get(
                "bev_map_reference_channel",
                None,
            )

        if reference_channel is not None:
            for item in frame_items:
                channel = item.get("channel", item.get("sensor", None))
                if channel == reference_channel:
                    return item

        for item in frame_items:
            channel = str(item.get("channel", item.get("sensor", ""))).lower()
            if "cam" in channel or "camera" in channel:
                return item

        if len(frame_items) == 0:
            raise ValueError(
                "Empty frame_items when selecting BEV map reference."
            )

        return frame_items[0]
    def get_instance_flow_images(self, segment):
        if len(segment) == 0:
            return []

        first_reference = self.get_bev_map_frame_reference(segment[0])
        world_from_reference = dwm.datasets.common.get_transform(
            first_reference["rotation"],
            first_reference["translation"],
        ).astype(np.float32)
        reference_from_world = np.linalg.inv(world_from_reference).astype(
            np.float32
        )
        category_prefixes = tuple(
            self.instance_flow_image_settings.get(
                "categories",
                MotionDataset.default_3dbox_color_table.keys(),
            )
        )
        corner_template = np.asarray(
            MotionDataset.default_3dbox_corner_template,
            dtype=np.float32,
        ).T
        frame_records = []
        camera_specs = []

        for frame_items in segment:
            frame_reference = self.get_bev_map_frame_reference(frame_items)
            world_from_frame = dwm.datasets.common.get_transform(
                frame_reference["rotation"],
                frame_reference["translation"],
            ).astype(np.float32)
            frame_from_world = np.linalg.inv(world_from_frame).astype(
                np.float32
            )
            reference_from_frame = (
                reference_from_world @ world_from_frame
            ).astype(np.float32)
            sample = MotionDataset.query(
                self.tables,
                self.indices,
                "sample",
                frame_reference["sample_token"],
            )
            annotations = MotionDataset.query_range(
                self.tables,
                self.indices,
                "sample_annotation",
                sample["token"],
                column_name="sample_token",
            )
            records = []
            for annotation in annotations:
                instance = MotionDataset.query(
                    self.tables,
                    self.indices,
                    "instance",
                    annotation["instance_token"],
                )
                category = MotionDataset.query(
                    self.tables,
                    self.indices,
                    "category",
                    instance["category_token"],
                )
                if not any(
                    category["name"].startswith(prefix)
                    for prefix in category_prefixes
                ):
                    continue
                scale = np.diag(
                    [
                        float(annotation["size"][1]),
                        float(annotation["size"][0]),
                        float(annotation["size"][2]),
                        1.0,
                    ]
                ).astype(np.float32)
                world_from_box = dwm.datasets.common.get_transform(
                    annotation["rotation"],
                    annotation["translation"],
                ).astype(np.float32)
                corners_frame = (
                    frame_from_world @ world_from_box @ scale @ corner_template
                )[:3].T
                center_reference = transform_point(
                    reference_from_frame,
                    corners_frame.mean(axis=0),
                )
                records.append(
                    {
                        "track_id": str(annotation["instance_token"]),
                        "corners_frame": corners_frame,
                        "position_reference": center_reference,
                    }
                )
            frame_records.append(records)

            specs = []
            for sample_data in frame_items:
                if not MotionDataset.check_sensor(
                    self.tables,
                    self.indices,
                    sample_data,
                    modality="camera",
                ):
                    continue
                calibrated_sensor = MotionDataset.query(
                    self.tables,
                    self.indices,
                    "calibrated_sensor",
                    sample_data["calibrated_sensor_token"],
                )
                intrinsic = np.asarray(
                    calibrated_sensor["camera_intrinsic"],
                    dtype=np.float32,
                )
                ego_from_camera = dwm.datasets.common.get_transform(
                    calibrated_sensor["rotation"],
                    calibrated_sensor["translation"],
                ).astype(np.float32)
                world_from_camera_ego = dwm.datasets.common.get_transform(
                    sample_data["rotation"],
                    sample_data["translation"],
                ).astype(np.float32)
                camera_from_frame = np.linalg.solve(
                    world_from_camera_ego @ ego_from_camera,
                    world_from_frame,
                ).astype(np.float32)
                specs.append(
                    {
                        "intrinsic": intrinsic,
                        "camera_from_frame": camera_from_frame,
                        "image_height": int(sample_data["height"]),
                        "image_width": int(sample_data["width"]),
                    }
                )
            if len(specs) == 0:
                raise ValueError("nuScenes instance flow requires at least one camera.")
            camera_specs.append(specs)

        return render_instance_flow_images(
            frame_records,
            camera_specs,
            self.instance_flow_image_settings,
        )

    def __init__(
        self, fs: fsspec.AbstractFileSystem, dataset_name: str,
        sequence_length: int, fps_stride_tuples: list, split=None,
        sensor_channels: list = ["CAM_FRONT"], keyframe_only: bool = False,
        enable_synchronization_check: bool = True,
        enable_scene_description: bool = False,
        enable_camera_transforms: bool = False,
        enable_ego_transforms: bool = False, enable_sample_data: bool = True,
        _3dbox_image_settings=None, hdmap_image_settings=None,
        image_segmentation_settings=None,
        foreground_region_image_settings=None, _3dbox_bev_settings=None,
        hdmap_bev_settings=None, image_description_settings=None,
        stub_key_data_dict=None,
        balanced_json_path=None, # 新增参数
        layout_token_settings: dict = None,
        instance_flow_image_settings=None,
        **kwargs
    
        
    ):
        self.fs = fs
        tables, self.indices = MotionDataset.load_tables(
            fs, dataset_name, MotionDataset.table_names,
            MotionDataset.prune_table_plan, MotionDataset.index_names, split)
        self.tables = tables
        ###########构建 scene name -> token########
        ##########################################
        self.scene_name_to_token = {}

        for scene in tables["scene"]:
            self.scene_name_to_token[scene["name"]] = scene["token"]
        self.sequence_length = sequence_length
        self.sensor_channels = sensor_channels # 确保这里存了传感器列表
        self.fps_stride_tuples = fps_stride_tuples
        self.enable_scene_description = enable_scene_description
        self.enable_camera_transforms = enable_camera_transforms
        self.enable_ego_transforms = enable_ego_transforms
        self.enable_sample_data = enable_sample_data
        self._3dbox_image_settings = _3dbox_image_settings
        self.hdmap_image_settings = hdmap_image_settings
        self.image_segmentation_settings = image_segmentation_settings
        self.foreground_region_image_settings = \
            foreground_region_image_settings
        self._3dbox_bev_settings = _3dbox_bev_settings
        self.hdmap_bev_settings = hdmap_bev_settings
        self.image_description_settings = image_description_settings
        self.stub_key_data_dict = stub_key_data_dict
        self.layout_token_settings = layout_token_settings
        self.instance_flow_image_settings = instance_flow_image_settings
        self.items = [] 
        self.motion_intervals = []
        # cache the map data
        if (
            self.hdmap_image_settings is not None or
            self.hdmap_bev_settings is not None
        ):
            self.map_expansion = {}
            self.map_expansion_dict = {}
            for i in tables["log"]:
                to_dict = ["node", "polygon"]
                if i["location"] not in self.map_expansion:
                    name = "expansion/{}.json".format(i["location"])
                    self.map_expansion[i["location"]] = json.loads(
                        fs.cat_file(name).decode())
                    self.map_expansion_dict[i["location"]] = {}
                    for j in to_dict:
                        self.map_expansion_dict[i["location"]][j] = {
                            k["token"]: k
                            for k in self.map_expansion[i["location"]][j]
                        }

        key_filter = (lambda i: i["is_key_frame"]) if keyframe_only else (lambda _: True)

        # Merge ego_pose into sample_data
        if "ego_pose" in tables:
            for i in tables["sample_data"]:
                pose = MotionDataset.query(
                    tables, self.indices, "ego_pose", i["ego_pose_token"])
                i.update({k: v for k, v in pose.items() if k not in i})

            tables.pop("ego_pose")
            self.indices.pop("ego_pose.token")

            
            # ===============================
            # 加载 balanced_json motion intervals
            # ===============================

            self.balanced_json_path = balanced_json_path
            use_balanced = balanced_json_path is not None
            
            DEFAULT_OVERLAP_RATIO = 0.8
            if use_balanced:
                if os.path.isabs(balanced_json_path):
                    with open(balanced_json_path, 'r', encoding='utf-8') as f:
                        raw_entries = json.load(f)
                else:
                    with self.fs.open(balanced_json_path, 'r') as f:
                        raw_entries = json.load(f)

                #print(f"[Dataset DEBUG] NUSSS Loading motion intervals from JSON: {len(raw_entries)} entries")
                #print(f"[TIME] JSON load: {time.time() - t_json:.3f}s")

                # ===============================
                # 构建 motion_intervals
                # ===============================

                for entry in raw_entries:

                    if entry["scene_name"] not in self.scene_name_to_token:
                        raise RuntimeError(
                            f"[Dataset ERROR] scene_name not found in dataset: {entry['scene_name']}"
                        )

                    scene_token = self.scene_name_to_token[entry["scene_name"]]

                    self.motion_intervals.append({
                        "scene": scene_token,
                        "start_ts": entry["start_timestamp"],
                        "end_ts": entry["end_timestamp"],
                        "angle": entry["angle"],
                        "dist": entry["dist"]
                    })

                #print(f"[Dataset DEBUG] Motion intervals loaded: {len(self.motion_intervals)}")
                

                if len(self.motion_intervals) == 0:
                    raise RuntimeError(
                        "[Dataset ERROR] No motion intervals loaded. Dataset will be empty."
                    )


                # ===============================
                # build scene -> interval bucket
                # ===============================

                t_bucket = time.time()

                self.motion_intervals_by_scene = {}

                for interval in self.motion_intervals:
                    s = interval["scene"]
                    if s not in self.motion_intervals_by_scene:
                        self.motion_intervals_by_scene[s] = []
                    self.motion_intervals_by_scene[s].append(interval)


                # ===============================
                # 构建 scene_channel_sample_data
                # ===============================

                t_scene_data = time.time()

                scene_channel_sample_data = [
                    (scene, [
                        sorted([
                            sample_data
                            for sample in MotionDataset.get_scene_samples(
                                tables, self.indices, scene)
                            for sample_data in MotionDataset.query_range(
                                tables, self.indices, "sample_data", sample["token"],
                                column_name="sample_token")
                            if MotionDataset.check_sensor(
                                tables, self.indices, sample_data, channel) and
                            key_filter(sample_data)
                        ], key=lambda x: x["timestamp"])
                        for channel in sensor_channels
                    ])
                    for scene in tables["scene"]
                ]


                # ===============================
                # enumerate_segments
                # ===============================


                t_enumerate = time.time()
                t_interval_match = 0

                total_windows = 0
                matched_windows_before_downsample = 0
                matched_windows = 0
                scene_window_counter = {}

                DEFAULT_OVERLAP_RATIO = 0.8

                KEEP_RATIO = 1
                DOWNSAMPLE_SEED = 1234
                rng = random.Random(DOWNSAMPLE_SEED)

                for scene, channel_sample_data_list in scene_channel_sample_data:

                    scene_intervals = self.motion_intervals_by_scene.get(scene["token"], [])

                    # 只在 use_balanced 时过滤 scene
                    if use_balanced and len(scene_intervals) == 0:
                        continue

                    for fps_stride_cfg in fps_stride_tuples:
                        if len(fps_stride_cfg) == 2:
                            fps, stride = fps_stride_cfg
                            overlap_ratio = DEFAULT_OVERLAP_RATIO
                        elif len(fps_stride_cfg) == 3:
                            fps, stride, overlap_ratio = fps_stride_cfg
                        else:
                            raise ValueError(
                                "Each item in fps_stride_tuples must be "
                                "(fps, stride) or (fps, stride, overlap_ratio), "
                                f"but got: {fps_stride_cfg}"
                            )

                        if not (0.0 <= overlap_ratio <= 1.0):
                            raise ValueError(
                                f"overlap_ratio must be in [0, 1], got: {overlap_ratio}"
                            )

                        for segment_tokens in MotionDataset.enumerate_segments(
                            channel_sample_data_list,
                            sequence_length,
                            fps,
                            stride,
                            enable_synchronization_check
                        ):

                            total_windows += 1

                            first_token = segment_tokens[0][0]
                            last_token = segment_tokens[-1][0]

                            first_sd = MotionDataset.query(
                                tables, self.indices, "sample_data", first_token
                            )
                            last_sd = MotionDataset.query(
                                tables, self.indices, "sample_data", last_token
                            )

                            window_start = first_sd["timestamp"]
                            window_end = last_sd["timestamp"]
                            window_duration = window_end - window_start

                            matched_interval = None

                            t_match_start = time.time()


                            for interval in scene_intervals:
                                overlap_start = max(window_start, interval["start_ts"])
                                overlap_end = min(window_end, interval["end_ts"])
                                overlap = overlap_end - overlap_start

                                if overlap <= 0:
                                    continue

                                if overlap >= overlap_ratio * window_duration:
                                    matched_interval = interval
                                    break

                            t_interval_match += time.time() - t_match_start

                            if matched_interval is None:
                                continue

                            matched_windows_before_downsample += 1

                            if rng.random() >= KEEP_RATIO:
                                continue

                            matched_windows += 1

                            scene_name = scene["name"]
                            if scene_name not in scene_window_counter:
                                scene_window_counter[scene_name] = 0
                            scene_window_counter[scene_name] += 1

                            self.items.append({
                                "scene": scene["token"],
                                "segment": segment_tokens,
                                "fps": fps,
                                "angle": matched_interval["angle"],
                                "dist": matched_interval["dist"]
                            })

                if total_windows == 0:
                    raise RuntimeError(
                        "[Dataset ERROR] enumerate_segments generated 0 windows."
                    )

                if matched_windows == 0:
                    raise RuntimeError(
                        "[Dataset ERROR] No windows matched motion intervals."
                    )

                #print("[nuscenceDataset DEBUG] Windows per scene (first 10):")
                for i, (k, v) in enumerate(scene_window_counter.items()):
                    if i > 10:
                        break
                    #print(f"   {k}: {v}")
            
            else:

                scene_channel_sample_data = [
                    (scene, [
                        sorted([
                            sample_data
                            for sample in MotionDataset.get_scene_samples(
                                tables, self.indices, scene)
                            for sample_data in MotionDataset.query_range(
                                tables, self.indices, "sample_data", sample["token"],
                                column_name="sample_token")
                            if MotionDataset.check_sensor(
                                tables, self.indices, sample_data, channel) and
                            key_filter(sample_data)
                        ], key=lambda x: x["timestamp"])
                        for channel in sensor_channels
                    ])
                    for scene in tables["scene"]
                ]

                self.items = []


                for scene, channel_sample_data in scene_channel_sample_data:
                    for fps_stride_cfg in self.fps_stride_tuples:
                        if len(fps_stride_cfg) == 2:
                            fps, stride = fps_stride_cfg
                            overlap_ratio = DEFAULT_OVERLAP_RATIO
                        elif len(fps_stride_cfg) == 3:
                            fps, stride, overlap_ratio = fps_stride_cfg
                        else:
                            raise ValueError(
                                "Each item in fps_stride_tuples must be "
                                "(fps, stride) or (fps, stride, overlap_ratio), "
                                f"but got: {fps_stride_cfg}"
                            )

                        if not (0.0 <= overlap_ratio <= 1.0):
                            raise ValueError(
                                f"overlap_ratio must be in [0, 1], got: {overlap_ratio}"
                            )

                        for segment in MotionDataset.enumerate_segments(
                            channel_sample_data,
                            self.sequence_length,
                            fps,
                            stride,
                            enable_synchronization_check
                        ):
                            self.items.append({
                            "segment": segment,
                            "fps": fps,
                            "scene": scene["token"],
                            "angle": 0.0,
                            "dist": 0.0
                        })

                self.items = dwm.common.SerializedReadonlyList(self.items)
                #print(f"[nuscenceDataset INFO] Total scenes: {len(scene_channel_sample_data)}")
                #print(f"[nuscenceDataset INFO] Final dataset size: {len(self.items)}")
            
            if image_description_settings is not None:
                with open(
                    image_description_settings["path"], "r", encoding="utf-8"
                ) as f:
                    self.image_descriptions = json.load(f)

                self.image_desc_rs = np.random.RandomState(
                    image_description_settings["seed"]
                    if "seed" in image_description_settings else None)

                with open(
                    image_description_settings["time_list_dict_path"], "r",
                    encoding="utf-8"
                ) as f:
                    self.time_list_dict = json.load(f)

            self.tables = {
                k: (
                    dwm.common.SerializedReadonlyList(v)
                    if k in MotionDataset.serialized_table_names else v
                )
                for k, v in tables.items()
            }

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index: int):
        item = self.items[index]
        scene = MotionDataset.query(
            self.tables, self.indices, "scene", item["scene"])
        segment = [
            [
                MotionDataset.query(
                    self.tables, self.indices, "sample_data", j)
                for j in i
            ]
            for i in item["segment"]
        ]

        result = {
            "fps": torch.tensor(item["fps"], dtype=torch.float32),
            "angle": torch.tensor(item["angle"] if "angle" in item else 0.0, dtype=torch.float32),
            "dist": torch.tensor(item["dist"] if "dist" in item else 0.0, dtype=torch.float32),
        }
        # ======= 新增：注入 JSON 里的 angle 和 dist =======
        # 获取当前样本的标识符（通常是 start_sample_token）
    

       # result["pts"] = torch.tensor([
       #     [
       #         (j["timestamp"] - segment[0][0]["timestamp"] + 500) // 1000
       #         for j in i
       #     ]
       #     for i in segment
       # ], dtype=torch.float32)
        images = []
        for i in segment:
            images_i = self.get_images(
                self.fs, self.tables, self.indices, i
            )
            if len(images_i) > 0:
                images.append(images_i)

        if len(images) > 0:
            result["images"] = images  # [sequence_length, view_count]

        if self.enable_camera_transforms:
            if "images" in result:
                result["camera_transforms"] = torch.stack([
                    torch.stack([
                        MotionDataset.get_transform(
                            self.tables, self.indices, "calibrated_sensor",
                            j["calibrated_sensor_token"], "pt")
                        for j in i
                        if MotionDataset.check_sensor(
                            self.tables, self.indices, j,
                            modality="camera")
                    ])
                    for i in segment
                ])
                result["camera_intrinsics"] = torch.stack([
                    torch.stack([
                        torch.tensor(
                            MotionDataset.query(
                                self.tables, self.indices,
                                "calibrated_sensor",
                                j["calibrated_sensor_token"]
                            )["camera_intrinsic"], dtype=torch.float32)
                        for j in i
                        if MotionDataset.check_sensor(
                            self.tables, self.indices, j,
                            modality="camera")
                    ])
                    for i in segment
                ])
                result["image_size"] = torch.stack([
                    torch.stack([
                        torch.tensor(
                            [j["width"], j["height"]], dtype=torch.long)
                        for j in i
                        if MotionDataset.check_sensor(
                            self.tables, self.indices, j,
                            modality="camera")
                    ])
                    for i in segment
                ])

        if self.enable_ego_transforms:
            result["ego_transforms"] = torch.stack([
                torch.stack([
                    dwm.datasets.common.get_transform(
                        j["rotation"], j["translation"], "pt")
                    for j, s in zip(i, self.sensor_channels)
                    if s != "LIDAR_TOP"
                ])
                for i in segment
            ])
            
        if self._3dbox_image_settings is not None:
            result["3dbox_images"] = [
                [
                    MotionDataset.get_3dbox_image(
                        self.tables, self.indices, j,
                        self._3dbox_image_settings)
                    for j in i
                    if MotionDataset.check_sensor(
                        self.tables, self.indices, j, modality="camera")
                ]
                for i in segment
            ]

        if self.hdmap_image_settings is not None:
            result["hdmap_images"] = [
                [
                    MotionDataset.get_hdmap_image(
                        self.map_expansion, self.map_expansion_dict,
                        self.tables, self.indices, j,
                        self.hdmap_image_settings)
                    for j in i
                    if MotionDataset.check_sensor(
                        self.tables, self.indices, j, modality="camera")
                ]
                for i in segment
            ]

        if self.instance_flow_image_settings is not None:
            result["instance_flow_images"] = self.get_instance_flow_images(
                segment
            )

        if self.image_segmentation_settings is not None:
            result["segmentation_images"] = [
                [
                    MotionDataset.get_segmentation_image(
                        self.fs, j, self.image_segmentation_settings)
                    for j in i
                    if MotionDataset.check_sensor(
                        self.tables, self.indices, j, modality="camera")
                ]
                for i in segment
            ]

        if self.foreground_region_image_settings is not None:
            result["foreground_region_images"] = [
                [
                    MotionDataset.get_foreground_region_image(
                        self.tables, self.indices, j,
                        self.foreground_region_image_settings)
                    for j in i
                    if MotionDataset.check_sensor(
                        self.tables, self.indices, j, modality="camera")
                ]
                for i in segment
            ]

        if self._3dbox_bev_settings is not None:
            result["3dbox_bev_images"] = [
                MotionDataset.get_3dbox_bev_image(
                    self.tables, self.indices, j, self._3dbox_bev_settings)
                for i in segment
                for j in i
                if MotionDataset.check_sensor(
                    self.tables, self.indices, j, modality="lidar")
            ]

        if self.hdmap_bev_settings is not None:
            result["hdmap_bev_images"] = [
                MotionDataset.get_hdmap_bev_image(
                    self.map_expansion,
                    self.map_expansion_dict,
                    self.tables,
                    self.indices,
                    self.get_bev_map_frame_reference(i),
                    self.hdmap_bev_settings,
                )
                for i in segment
            ]

        if self.image_description_settings is not None:
            image_captions = [
                dwm.datasets.common.align_image_description_crossview([
                    MotionDataset.get_image_description(
                        self.tables, self.indices, self.image_descriptions,
                        self.time_list_dict, scene["token"], j)
                    for j in i
                    if MotionDataset.check_sensor(
                        self.tables, self.indices, j, modality="camera")
                ], self.image_description_settings)
                for i in segment
            ]
            result["image_description"] = [
                [
                    dwm.datasets.common.make_image_description_string(
                        j, self.image_description_settings, self.image_desc_rs)
                    for j in i
                ]
                for i in image_captions
            ]
        if self.layout_token_settings is not None:
            bbox_token_corners_list = []
            bbox_token_classes_list = []
            bbox_token_masks_list = []

            for frame_items in segment:
                bbox_corners, bbox_classes, bbox_masks = \
                    self.get_layout_token_boxes(frame_items)

                bbox_token_corners_list.append(bbox_corners)
                bbox_token_classes_list.append(bbox_classes)
                bbox_token_masks_list.append(bbox_masks)

            result["bbox_token_corners"] = torch.stack(
                bbox_token_corners_list,
                dim=0,
            )
            result["bbox_token_classes"] = torch.stack(
                bbox_token_classes_list,
                dim=0,
            )
            result["bbox_token_masks"] = torch.stack(
                bbox_token_masks_list,
                dim=0,
            )
        dwm.datasets.common.add_stub_key_data(self.stub_key_data_dict, result)

        return result
